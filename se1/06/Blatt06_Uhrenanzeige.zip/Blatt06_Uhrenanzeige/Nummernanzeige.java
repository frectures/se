
/**
 * Die Klasse Nummernanzeige modelliert Objekte, die Werte von Null bis zu einem
 * vorgegebenen Limit anzeigen koennen. Das Limit wird definiert, wenn ein Exemplar
 * einer Nummernanzeige erzeugt wird. Die darstellbaren Werte reichen von Null
 * bis Limit-1.
 * Wenn beispielsweise eine Nummernanzeige fuer die Sekunden einer digitalen
 * Uhr verwendet werden soll, wuerde man ihr Limit auf 60 setzen, damit die
 * dargestellten Werte von 0 bis 59 reichen. Wenn der Wert einer Nummernanzeige
 * erhoeht wird, wird bei Erreichen des Limits der Wert automatisch auf Null
 * zurueckgesetzt.
 * 
 * @author Michael Kolling, David J. Barnes, Axel Schmolitzky
 * @version WiSe 2013
 */
class Nummernanzeige  
{
    private final int _limit;
    private int _wert;

    /**
     * Konstruktor fuer Exemplare der Klasse Nummernanzeige
     * @param anzeigeGrenze das Limit fuer die Anzeige
     */
    public Nummernanzeige(int anzeigeGrenze)
    {
    }

    /**
     * Liefere das Limit dieser Anzeige.
     */
    public int gibLimit()  
    {
    }

    /**
     * Liefere den aktuellen Wert dieser Anzeige.
     */
    public int gibWert()  
    {
    }
    
    /**
     * Liefere den Anzeigewert, also den Wert dieser Anzeige als einen String
     * mit zwei Ziffern. Wenn der Wert der Anzeige kleiner als zehn ist, wird
     * das Ergebnis mit einer fuehrenden Null versehen.
     */
    public String gibAnzeigewert()
    {
    }

    /**
     * Setze den Wert der Anzeige auf den angegebenen 'wert'.
     * Wenn der angegebene Wert unter Null oder groesser gleich
     * dem Limit ist, tue nichts.
     * 
     * @param 
     */
    public void setzeWert(int wert)
    {
    }

    /**
     * Erhoehe den Wert dieser Anzeige um Eins. Wenn das Limit erreicht ist,
     * setze den Wert wieder auf Null.
     */
    public void erhoehen()
    {
    }
}
