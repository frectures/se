import java.io.PrintStream;

/**
 * Eine Stoppuhr vereinfacht das Messen von Zeitabschnitten.
 * 
 * @author Fredrik Winkler
 * @version Januar 2012
 */
class Stoppuhr
{
    private final PrintStream _out;
    private long _start;
    
    /**
     * Startet den ersten Messvorgang.
     * @param out ein PrintStream, ueber den die Messdaten ausgegeben werden soll
     * @param beschreibung eine Beschreibung des gemessenen Vorgangs
     */
    public Stoppuhr(PrintStream out, String beschreibung)
    {
        _out = out;
        _out.println("Starte Messung: " + beschreibung);
        _start = System.nanoTime();
    }

    /**
     * Stoppt den Messvorgang und startet einen neuen.
     */
    public void stopp()
    {
        long now = System.nanoTime();
        long difference = now - _start;
        long ms = difference / 1000000;
        _out.println("Gemessene Zeit: " + ms + " ms");
        printWarningsForShortIntervals(ms);
        _start = System.nanoTime();
    }

    /**
     * Gibt fuer kurze Messintervalle eine entsprechende Warnung aus.
     */
    private void printWarningsForShortIntervals(long ms)
    {
        if (ms < 100)
        {
            _out.println("*** Messintervall ist sehr kurz ***");
        }
        else if (ms < 1000)
        {
            _out.println("*** Messintervall ist recht kurz ***");
        }
    }
}
